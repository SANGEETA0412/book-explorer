// backend/index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Book = require("./src/models/Book");
 // create Book model as in scraper

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/book_explorer', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// GET /api/books
app.get('/api/books', async (req, res) => {
  const { page = 1, limit = 10, search = '', rating, minPrice, maxPrice, inStock } = req.query;
  const filter = {};

  if (search) filter.title = { $regex: search, $options: 'i' };
  if (rating) filter.rating = rating;
  if (inStock) filter.availability = inStock === 'true' ? { $regex: 'In stock' } : { $not: /In stock/ };
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = parseFloat(minPrice.replace('£', ''));
    if (maxPrice) filter.price.$lte = parseFloat(maxPrice.replace('£', ''));
  }

  const books = await Book.find(filter)
    .skip((page - 1) * limit)
    .limit(parseInt(limit));

  const total = await Book.countDocuments(filter);

  res.json({ books, total, page: parseInt(page), pages: Math.ceil(total / limit) });
});

// GET /api/books/:id
app.get('/api/books/:id', async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) return res.status(404).json({ message: 'Book not found' });
  res.json(book);
});

// POST /api/refresh (bonus)
app.post('/api/refresh', async (req, res) => {
  const { exec } = require('child_process');
  exec('node ../scraper/scraper.js', (error, stdout, stderr) => {
    if (error) return res.status(500).send(stderr);
    res.send(stdout);
  });
});

app.listen(5000, () => console.log('Backend running on http://localhost:5000'));
