
const axios = require('axios');
const cheerio = require('cheerio');
const mongoose = require('mongoose');

const BASE_URL = 'https://books.toscrape.com/catalogue/page-1.html';

const bookSchema = new mongoose.Schema({
  title: String,
  price: String,
  availability: String,
  rating: String,
  url: String,
  thumbnail: String
});

const Book = mongoose.model('Book', bookSchema);

async function scrapePage(url) {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const bookElements = $('.product_pod');
    for (let i = 0; i < bookElements.length; i++) {
      const el = bookElements[i];
      const title = $(el).find('h3 a').attr('title');
      const bookUrl = 'https://books.toscrape.com/catalogue/' + $(el).find('h3 a').attr('href');
      const price = $(el).find('.price_color').text();
      const availability = $(el).find('.availability').text().trim();
      const rating = $(el).find('p.star-rating').attr('class').split(' ')[1];
      const thumbnail = 'https://books.toscrape.com/' + $(el).find('img').attr('src').replace('../', '');

      // Save to DB with proper await
      await Book.create({ title, price, availability, rating, url: bookUrl, thumbnail });
    }

    const next = $('.next a').attr('href');
    if (next) {
      const nextUrl = url.replace(/page-\d+\.html/, next);
      await scrapePage(nextUrl);
    }
  } catch (err) {
    console.error('Scraping error:', err);
  }
}

async function main() {
  try {
    // Connect to MongoDB and wait for connection
    await mongoose.connect('mongodb://127.0.0.1:27017/book_explorer', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('MongoDB connected!');

    // Clear old data (optional)
    await Book.deleteMany({});

    await scrapePage(BASE_URL);

    console.log('Scraping completed!');
    await mongoose.connection.close();
  } catch (err) {
    console.error('MongoDB connection error:', err);
  }
}

main();
