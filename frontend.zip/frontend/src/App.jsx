import React, { useState, useEffect } from 'react';
import SearchBar from './components/SearchBar';
import BookList from './components/BookList';

function App() {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetch(`http://localhost:5000/api/books?search=${searchTerm}`)
      .then(res => res.json())
      .then(data => setBooks(data.books));
  }, [searchTerm]);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Book Explorer</h1>
      <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <BookList books={books} />
    </div>
  );
}

export default App;
