const express = require('express');
const router = express.Router();
const controller = require('../controllers/bookController');

// List all books with filters, pagination
router.get('/', controller.listBooks);

// Get single book by id
router.get('/:id', controller.getBook);

// Trigger refresh (optional)
router.post('/refresh', controller.refresh);

module.exports = router;
