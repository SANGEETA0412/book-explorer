const Book = require('../models/Book');

function parseRange(range) {
  if (!range) return {};
  const [minS, maxS] = range.split('-');
  const q = {};
  if (minS) q.$gte = parseFloat(minS);
  if (maxS) q.$lte = parseFloat(maxS);
  return q;
}

exports.listBooks = async (req, res) => {
  try {
    const page = parseInt(req.query.page || '1');
    const limit = Math.min(parseInt(req.query.limit || '12'), 100);
    const skip = (page - 1) * limit;

    const filters = {};
    if (req.query.rating) filters.rating = parseInt(req.query.rating);
    if (req.query.in_stock) filters.in_stock = req.query.in_stock === 'true';
    if (req.query.price_range) {
      const range = parseRange(req.query.price_range);
      if (Object.keys(range).length) filters.price = range;
    }
    if (req.query.q) {
      filters.title = { $regex: req.query.q, $options: 'i' };
    }

    const total = await Book.countDocuments(filters);
    const books = await Book.find(filters).skip(skip).limit(limit).sort({ scraped_at: -1 });

    res.json({
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
      data: books
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getBook = async (req, res) => {
  try {
    const b = await Book.findById(req.params.id);
    if (!b) return res.status(404).json({ error: 'Not found' });
    res.json(b);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.refresh = async (req, res) => {
  res.status(202).json({ status: 'refresh endpoint placeholder' });
};
